package behaviours;

public interface IChange {

    void changeAttack();

}
