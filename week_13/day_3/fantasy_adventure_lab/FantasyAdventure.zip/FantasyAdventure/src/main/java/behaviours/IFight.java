package behaviours;

import players.Player;

public interface IFight {

    void fight();


}
