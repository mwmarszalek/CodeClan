package behaviours;

import players.cleric.HealingType;

public interface IHeal {

    void changeHeal(HealingType healingType);

}
