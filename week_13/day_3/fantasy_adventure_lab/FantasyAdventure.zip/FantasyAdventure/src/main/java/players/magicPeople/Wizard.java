package players.magicPeople;

public class Wizard extends MagicPerson {
    public Wizard(String name, int healthBar, SpellType spellType, CreatureType creatureType) {
        super(name, healthBar, spellType, creatureType);
    }

    @Override
    public void fight() {

    }

    @Override
    public void changeAttack() {

    }
}
