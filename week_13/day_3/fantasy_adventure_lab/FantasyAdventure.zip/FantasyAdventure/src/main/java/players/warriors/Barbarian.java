package players.warriors;

public class Barbarian extends Warrior {
    public Barbarian(String name, int healthBar, WeaponType weaponType) {
        super(name, healthBar, weaponType);
    }

    @Override
    public void fight() {

    }

    @Override
    public void changeAttack() {

    }
}
