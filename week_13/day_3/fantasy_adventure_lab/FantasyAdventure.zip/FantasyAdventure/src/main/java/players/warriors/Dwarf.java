package players.warriors;

public class Dwarf extends Warrior{
    public Dwarf(String name, int healthBar, WeaponType weaponType) {
        super(name, healthBar, weaponType);
    }


    @Override
    public void fight() {

    }

    @Override
    public void changeAttack() {

    }
}
