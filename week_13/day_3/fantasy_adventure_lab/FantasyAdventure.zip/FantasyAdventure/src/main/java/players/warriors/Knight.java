package players.warriors;

public class Knight extends Warrior{
    public Knight(String name, int healthBar, WeaponType weaponType) {
        super(name, healthBar, weaponType);
    }

    @Override
    public void fight() {

    }

    @Override
    public void changeAttack() {

    }
}
